SELECT name FROM songs
ORDER BY duration_ms
DESC LIMIT 5;