SELECT year, title FROM movies
WHERE title LIKE 'Harry Potter%'
ORDER BY year ASC;