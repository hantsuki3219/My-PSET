SELECT COUNT(rating) FROM ratings
WHERE rating = 10;