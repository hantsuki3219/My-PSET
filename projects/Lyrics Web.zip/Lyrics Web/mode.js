function toggleDarkmode()
{
    document.body.classList.toggle('dark-mode');
}

if (localStorage.getItem('theme') === 'dark')
{
    document.body.classList.add('dark-mode');
}

function toggleDarkmode()
{
    document.body.classList.toggle('dark-mode');
    if (document.body.classList.contains('dark-mode'))
    {
        localStorage.setItem('theme', 'dark');
    }
    else
    {
        localStorage.setItem('theme', 'light');
    }
}

const toggle = document.getElementById('darkModeToggle');

// โหลดค่าเก่าจาก localStorage (จำโหมด)
if (localStorage.getItem('theme') === 'dark')
{
    document.body.classList.add('dark-mode');
    toggle.checked = true;
}

toggle.addEventListener('change', function()
    {
    document.body.classList.toggle('dark-mode', this.checked);
    localStorage.setItem('theme', this.checked ? 'dark' : 'light');
    }
);